package PageObjects;

import Utils.DatosExcel;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;

import java.io.IOException;

@DefaultUrl("https://demoqa.com/")

public class WebTablesObject extends PageObject {
    DatosExcel datosExcel = new DatosExcel();

    By lblClicElements = By.xpath("//div[@class =\"card-up\"]");
    By lblclicwebElemnets = By.xpath("//div[@class=\"element-list collapse show\"]/ul[1]/li[4]");
    By btnAdd = By.id("addNewRecordButton");
    By txtFirstName = By.id("firstName");
    By txtLastName = By.id("lastName");
    By txtEmail = By.id("userEmail");
    By txtAge = By.id("age");
    By txtSalary = By.id("salary");
    By txtDepartment  = By.id("department");
    By btnSubmit = By.id("submit");
    //Creo Una variable Tipo String para almacenar la informacion de la Hoja y tomar este dato como comparativo al momento de realizar la validacion
    String  Validacion = datosExcel.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,0);
    //concateno esta variable a mi Xpath para que esta sea mi validacion cuando busque en la pagina
    //La idea de esto es que cada vez que alguien modifique el excel busque si o si el nombre que ingresaron
    By lblValidacionSubmit = By.xpath("//*[contains(text(),'"+Validacion+"')]");
    By btnDelete = By.id("delete-record-4");

    public WebTablesObject() throws IOException {
    }

    public By getLblClicElements() {

        return lblClicElements;
    }

    public By getLblclicwebElemnets() {

        return lblclicwebElemnets;
    }

    public By getBtnAdd() {

        return btnAdd;
    }

    public By getTxtFirstName() {
        return txtFirstName;
    }

    public By getTxtLastName() {
        return txtLastName;
    }

    public By getTxtEmail() {
        return txtEmail;
    }

    public By getTxtAge() {
        return txtAge;
    }

    public By getTxtSalary() {
        return txtSalary;
    }

    public By getTxtDepartment() {
        return txtDepartment;
    }

    public By getBtnSubmit() {
        return btnSubmit;
    }

    public By getLblValidacionSubmit() {
        return lblValidacionSubmit;
    }

    public By getBtnDelete() {
        return btnDelete;
    }
}
