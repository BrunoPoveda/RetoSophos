package PageObjects;

import Utils.DatosExcel;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;

import java.io.IOException;
@DefaultUrl("https://demoqa.com/")

public class DatePickerObject extends PageObject {


    By lblClicWidgets = By.xpath("//*[@id=\"app\"]/div/div/div[2]/div/div[4]/div");
    By lblClicDatePicker = By.xpath("//div[@class=\"element-list collapse show\"]/ul[1]/li[3]");
    By txtSelectDate = By.id("datePickerMonthYearInput");
    By txtDateAndTime = By.id("dateAndTimePickerInput");
    By msjValidacionSelectDate = By.xpath("//*[@id=\"datePickerMonthYearInput\"]");
    By msjValidacionDateAndTime = By.xpath("//*[@id=\"dateAndTimePickerInput\"]");


    public DatePickerObject() throws IOException {
    }


    public By getLblClicDatePicker() {
        return lblClicDatePicker;
    }

    public By getLblClicWidgets() {
        return lblClicWidgets;
    }

    public By getTxtSelectDate() {
        return txtSelectDate;
    }

    public By getTxtDateAndTime() {
        return txtDateAndTime;
    }

    public By getMsjValidacionSelectDate() {
        return msjValidacionSelectDate;
    }

    public By getMsjValidacionDateAndTime() {
        return msjValidacionDateAndTime;
    }
}
