package PageObjects;

import Utils.DatosExcel;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

import java.io.IOException;

@DefaultUrl("https://demoqa.com/")

public class AlertObject extends PageObject {



    By lblClicAlertAndFrames = By.xpath("//*[@id=\"app\"]/div/div/div[2]/div/div[3]/div");
    By lblClicAlert = By.xpath("//div[@class=\"element-list collapse show\"]/ul[1]/li[2]");
    By btnAlertButton = By.id("alertButton");
    By btnTimeAlertButton = By.id("timerAlertButton");
    By btnConfirmButton = By.id("confirmButton");
    By btnPromtButton = By.id("promtButton");
    By msjValidacionAlerts = By.xpath("//*[@id=\"javascriptAlertsWrapper\"]/div[3]/div[1]");


    public AlertObject() throws IOException {
    }


    public By getLblClicAlertAndFrames() {
        return lblClicAlertAndFrames;
    }

    public By getLblClicAlert() {
        return lblClicAlert;
    }

    public By getBtnAlertButton() {
        return btnAlertButton;
    }

    public By getBtnTimeAlertButton() {
        return btnTimeAlertButton;
    }

    public By getBtnConfirmButton() {
        return btnConfirmButton;
    }

    public By getBtnPromtButton() {
        return btnPromtButton;
    }

    public By getMsjValidacionAlerts() {
        return msjValidacionAlerts;
    }
}
