package Steps;

import PageObjects.DatePickerObject;
import Utils.DatosExcel;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.io.IOException;

import static org.junit.Assert.*;

public class DatePickerSteps {
    DatePickerObject datePickerObject = new DatePickerObject();
    DatosExcel datos = new DatosExcel();

    public DatePickerSteps() throws IOException {
    }

    @Step
    public void clicWidgets (){
        datePickerObject.getDriver().findElement(datePickerObject.getLblClicWidgets()).click();
    }
    @Step
    public void clicDatePicker () {
        JavascriptExecutor jse = (JavascriptExecutor) datePickerObject.getDriver();
        WebElement element = datePickerObject.getDriver().findElement(datePickerObject.getLblClicDatePicker());
        jse.executeScript("arguments[0].scrollIntoView()", element);
        datePickerObject.getDriver().findElement(datePickerObject.getLblClicDatePicker()).click();
    }
        @Step
        public void llenarSelectDate () throws IOException {

            datePickerObject.getDriver().findElement(datePickerObject.getTxtSelectDate()).sendKeys(Keys.chord(Keys.CONTROL, "a"));
            datePickerObject.getDriver().findElement(datePickerObject.getTxtSelectDate()).sendKeys(Keys.DELETE);
            datePickerObject.getDriver().findElement(datePickerObject.getTxtSelectDate()).sendKeys(datos.leerDatoExcel("DatePicker","src\\main\\java\\Utils\\Datos.xlsx",1,0));
            datePickerObject.getDriver().findElement(datePickerObject.getTxtSelectDate()).sendKeys(Keys.ENTER);

        }

    @Step
    public void llenarDateAndTime () throws IOException {

        datePickerObject.getDriver().findElement(datePickerObject.getTxtDateAndTime()).sendKeys(Keys.chord(Keys.CONTROL, "a"));
        datePickerObject.getDriver().findElement(datePickerObject.getTxtDateAndTime()).sendKeys(Keys.DELETE);
        datePickerObject.getDriver().findElement(datePickerObject.getTxtDateAndTime()).sendKeys(datos.leerDatoExcel("DatePicker","src\\main\\java\\Utils\\Datos.xlsx",1,1));
        datePickerObject.getDriver().findElement(datePickerObject.getTxtDateAndTime()).sendKeys(Keys.ENTER);
    }

    @Step
    public void validacionSelectDate() throws IOException {
        //Dejo documentado ya que no logre realizar validacion me sale un error que No logre solventar
       //String validacion = datePickerObject.getDriver().findElement(datePickerObject.getMsjValidacionSelectDate()).getText();
        //assertThat(validacion.contains("02/27/1997"), Matchers.is(true));

    }

    @Step
    public void validacionDateAndTime () throws IOException {
        //Dejo documentado ya que no logre realizar validacion me sale un error que No logre solventar
     // String validacion2 = datePickerObject.getDriver().findElement(datePickerObject.getMsjValidacionDateAndTime()).getText();
      //assertThat(validacion2.contains("January 1, 2021 12:00 AM"), Matchers.is(true));

    }
}

