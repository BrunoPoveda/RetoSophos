package Steps;


import PageObjects.AlertObject;
import Utils.DatosExcel;
import cucumber.api.java.bs.A;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;

import java.io.IOException;

import static org.junit.Assert.assertThat;

public class AlertSteps {
    AlertObject alertObject = new AlertObject();
    DatosExcel datosExcel = new DatosExcel();

    public AlertSteps() throws IOException {
    }

    @Step
    public void clicAlertAndFrame (){
        alertObject.getDriver().findElement(alertObject.getLblClicAlertAndFrames()).click();
    }

    @Step
    public void clicAlert (){
        alertObject.getDriver().findElement(alertObject.getLblClicAlert()).click();
    }

    @Step
    public void clicAlertButton (){
        alertObject.getDriver().findElement(alertObject.getBtnAlertButton()).click();
        alertObject.getDriver().switchTo().alert().accept();
    }


    @Step
    public void clicTimeAlertButton () throws InterruptedException {
        alertObject.getDriver().findElement(alertObject.getBtnTimeAlertButton()).click();
        Thread.sleep(6000);
        alertObject.getDriver().switchTo().alert().accept();
    }

    @Step
    public void clicConfirmButton () throws InterruptedException {
        alertObject.getDriver().findElement(alertObject.getBtnConfirmButton()).click();
        alertObject.getDriver().switchTo().alert().accept();
    }

    @Step
    public void clicPromtButton () throws InterruptedException, IOException {
        alertObject.getDriver().findElement(alertObject.getBtnPromtButton()).click();
        alertObject.getDriver().switchTo().alert().sendKeys(datosExcel.leerDatoExcel("Alerts","src\\main\\java\\Utils\\Datos.xlsx",1,0));
        alertObject.getDriver().switchTo().alert().accept();
    }

    @Step
    public void validacionAlerts () throws IOException {

        String validacion = alertObject.getDriver().findElement(alertObject.getMsjValidacionAlerts()).getText();
        assertThat(validacion.contains("You selected Ok"), Matchers.is(true));



    }
}

