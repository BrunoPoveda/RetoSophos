package Steps;

import PageObjects.WebTablesObject;
import Utils.DatosExcel;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;

import java.io.IOException;

import static org.junit.Assert.*;

public class WebTablesSteps {

    WebTablesObject webTablesObject = new WebTablesObject();
    DatosExcel datos = new DatosExcel();

    public WebTablesSteps() throws IOException {
    }

    @Step
    public void abrirNavegador (){
        webTablesObject.open();
    }

    @Step
    public void clicElements (){
        webTablesObject.getDriver().findElement(webTablesObject.getLblClicElements()).click();
    }

    @Step
    public void clicWebElements (){
       webTablesObject.getDriver().findElement(webTablesObject.getLblclicwebElemnets()).click();

        }

    @Step
    public void clicAdd () {
        webTablesObject.getDriver().findElement(webTablesObject.getBtnAdd()).click();
    }

    @Step
    public void firstName () throws IOException {
        webTablesObject.getDriver().findElement(webTablesObject.getTxtFirstName()).sendKeys(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,0));
    }

    @Step
    public void lastName () throws IOException {
        webTablesObject.getDriver().findElement(webTablesObject.getTxtLastName()).sendKeys(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,1));
    }
    @Step
    public void Email () throws IOException {
        webTablesObject.getDriver().findElement(webTablesObject.getTxtEmail()).sendKeys(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,2));
    }

    @Step
    public void Age () throws IOException {
        webTablesObject.getDriver().findElement(webTablesObject.getTxtAge()).sendKeys(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,3));
    }

    @Step
    public void Salary () throws IOException {
        webTablesObject.getDriver().findElement(webTablesObject.getTxtSalary()).sendKeys(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,4));
    }
    @Step
    public void Department () throws IOException {
        webTablesObject.getDriver().findElement(webTablesObject.getTxtDepartment()).sendKeys(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,5));
    }
    @Step
    public void clicSubmit() {

        webTablesObject.getDriver().findElement(webTablesObject.getBtnSubmit()).click();
    }
    @Step
    public void validacionSubmit() throws IOException {

        String validacion = webTablesObject.getDriver().findElement(webTablesObject.getLblValidacionSubmit()).getText();
        assertThat(validacion.contains(datos.leerDatoExcel("WebTables","src\\main\\java\\Utils\\Datos.xlsx",1,0)), Matchers.is(true));

    }
    @Step
    public void clicDelete() {

        webTablesObject.getDriver().findElement(webTablesObject.getBtnDelete()).click();
    }



}




