package com.demoqa.www.stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import Steps.WebTablesSteps;

import java.io.IOException;

public class WebTablesStepsDefinitions {

    @Steps
    WebTablesSteps webTablesSteps;

    @Given("^el actor ingresa a la pagina principal$")
    public void elActorIngresaALaPaginaPrincipal() {
        webTablesSteps.abrirNavegador();
    }

    @When("^el actor da clic en elements$")
    public void elActorDaClicEnElements() {
        webTablesSteps.clicElements();
    }

    @When("^el actor da clic en web tables$")
    public void elActorDaClicEnWebTables() {

        webTablesSteps.clicWebElements();
    }
    @When("^el actor agrega informacion solicitada y envia informacion$")
    public void elActorAgregaInformacionSolicitadaYEnviaInformacion() throws IOException {
        webTablesSteps.clicAdd();
        webTablesSteps.firstName();
        webTablesSteps.lastName();
        webTablesSteps.Email();
        webTablesSteps.Age();
        webTablesSteps.Salary();
        webTablesSteps.Department();
        webTablesSteps.clicSubmit();
    }

    @Then("^el actor elimina informacion en formulario$")
    public void elActorEliminaInformacionEnFormulario() {
    webTablesSteps.clicDelete();
    }

    @Then("^el actor visualiza su informacion$")
    public void elActorVisualizaSuInformacion() throws IOException {
    webTablesSteps.validacionSubmit();
    }



}
