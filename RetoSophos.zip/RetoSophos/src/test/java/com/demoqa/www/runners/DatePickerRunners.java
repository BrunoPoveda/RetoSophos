package com.demoqa.www.runners;


import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src//test//resources//datePicker.feature",
        glue = "com.demoqa.www.stepDefinitions",
        snippets = SnippetType.CAMELCASE)

public class DatePickerRunners {

}
