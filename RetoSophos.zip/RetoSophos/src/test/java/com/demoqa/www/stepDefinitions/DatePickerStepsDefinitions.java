package com.demoqa.www.stepDefinitions;

import Steps.DatePickerSteps;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;

public class DatePickerStepsDefinitions {

    @Steps
    DatePickerSteps datePickerSteps;

    @When("^el actor da clic en widgets$")
    public void elActorDaClicEnWidgets() {

        datePickerSteps.clicWidgets();
    }

    @When("^el actor da clic en date picker$")
    public void elActorDaClicEnDatePicker() {

        datePickerSteps.clicDatePicker();
    }

    @When("^el actor selecciona una fecha de select day$")
    public void elActorSeleccionaUnaFechaDeSelectDay() throws IOException {
        datePickerSteps.llenarSelectDate();
    }

    @Then("^el actor visualiza la fecha de select day$")
    public void elActorVisualizaLaFechaDeSelectDay() throws IOException {
    datePickerSteps.validacionSelectDate();

    }

    @When("^el actor selecciona una fecha de date and time$")
    public void elActorSeleccionaUnaFechaDeDateAndTime() throws IOException {
        datePickerSteps.llenarDateAndTime();
    }

    @Then("^el actor visualiza su fecha de date and time$")
    public void elActorVisualizaSuFechaDeDateAndTime() throws IOException {
        datePickerSteps.validacionDateAndTime();
    }

}
