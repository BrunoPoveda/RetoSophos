package com.demoqa.www.stepDefinitions;

import Steps.AlertSteps;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;

public class AlertStepsDefinitions {
    @Steps
    AlertSteps alertSteps;

    @When("^el actor da clic en alerts Frame and Windows$")
    public void elActorDaClicEnAlertsFrameAndWindows() {
        alertSteps.clicAlertAndFrame();
    }


    @When("^el actor da clic en alerts$")
    public void elActorDaClicEnAlerts() {
    alertSteps.clicAlert();
    }

    @When("^el actor interactua con los alerts$")
    public void elActorInteractuaConLosAlerts() throws InterruptedException, IOException {
        alertSteps.clicAlertButton();
        alertSteps.clicTimeAlertButton();
        alertSteps.clicConfirmButton();
        alertSteps.clicPromtButton();
    }

    @Then("^el actor visualiza completado los alerts$")
    public void elActorVisualizaCompletadoLosAlerts() throws IOException {
    alertSteps.validacionAlerts();
    }

}
